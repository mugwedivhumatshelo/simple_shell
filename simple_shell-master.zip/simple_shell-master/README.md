This is a readme for simple shell project done with a partner
